
<?php
    $host = "localhost";
    $username = "root";
    $password = "1234";
    $database = "inventory";
   $mysqli=mysqli_connect($host,$username,$password,$database);
    //functions of add.php
   ?>


 